#!/bin/bash
dotnet /home/pi/Desktop/MLServer/DDNSUpdater.dll
