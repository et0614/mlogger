#!/bin/bash
dotnet /home/pi/Desktop/MLServer/MLResumer.dll
